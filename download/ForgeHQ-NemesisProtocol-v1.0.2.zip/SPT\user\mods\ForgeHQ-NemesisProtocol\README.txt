NEMESIS PROTOCOL v1.0.2

INSTALL
Extract NemesisProtocol-v1.0.2.zip into the game root that contains:

BepInEx
EscapeFromTarkov.exe
SPT

The archive installs both required components:

BepInEx\plugins\ForgeHQ-NemesisProtocol\ForgeHQ.NemesisProtocol.Client.dll
SPT\user\mods\ForgeHQ-NemesisProtocol\ForgeHQ.NemesisProtocol.dll

BACK UP FIRST
SPT\user\mods\ForgeHQ-NemesisProtocol\data\profiles

WHY THE CLIENT DLL IS REQUIRED
EFT randomly chooses a PMC profile after SPT returns a generated preset batch.
Server-side list ordering cannot guarantee that the prepared Nemesis is selected.

The bundled client DLL:

- Retrieves the exact prepared Nemesis profile ID from the server.
- Selects that exact profile instead of EFT's random matching PMC.
- Confirms when GameWorld registers the Nemesis as a live player.
- Reports whether the Nemesis later died or was removed while alive.

The server atomically claims one profile during parallel SPT/APBS batch
generation, ensuring that no second PMC in the batch receives the Nemesis name.

APBS still owns the generated level, equipment, inventory and loadout.
ORBIT and installed AI frameworks still control the normal PMC role and behavior.

SPAWN ACCOUNTING
Only a client-confirmed live profile or an exact matching post-raid profile ID
can change encounter statistics. Generated profiles that never become live bots
do not produce encounters, progression or messages.

If EFT or Fika reassigns the live bot's profile ID in the post-raid result, a
player defeat is accepted only when the client confirmed that Nemesis live and
dead and the current victim record also matches its exact name, faction, normal
PMC role, location and generated level.

Messenger status and dossier commands show clean gameplay statistics. Internal
spawn-selection diagnostics remain limited to the server and BepInEx logs.

BUILD FROM SOURCE
The .NET 9 SDK and an SPT 4.0.13 game installation are required.

Run:

powershell -ExecutionPolicy Bypass -File .\build.ps1 -GameRoot "D:\Your SPT Game Folder"

The finished archive is created at:

release\NemesisProtocol-v1.0.2.zip

EXPECTED LOGS
Client BepInEx log:

[Nemesis Protocol Client] v1.0.2 loaded. Exact-profile selection and live-spawn confirmation are active.
[Nemesis Protocol Client] Selected exact prepared profile <id> (<name>)...

Server log when a return is successful:

[Nemesis Protocol] Prepared <name> as an ordinary PMC profile candidate...
[Nemesis Protocol] Client selected prepared Nemesis profile...
[Nemesis Protocol] LIVE SPAWN CONFIRMED by client...

Migrated v1.0.1 profiles may contain generated-looking customization IDs that do
not exist in EFT. v1.0.2 validates persisted appearance IDs against SPT's live
customization database and uses the newly generated PMC's safe appearance when
an old record cannot be validated.

After a malformed legacy appearance is discarded, the next valid generated PMC
appearance is saved as that rival's permanent visual identity. Later appearances
reuse the same head, clothing, hands and voice.

Schema 6 removes obsolete legacy diagnostic fields while preserving existing
rival identity, manually tuned levels, progression, encounters and statistics.

TEST
1. Back up data\profiles.
2. Extract the archive into the game root.
3. Confirm both DLLs report version 1.0.2.0.
4. Start the SPT server and launcher from the same installation.
5. Set SpawnChancePercent to 100 for testing.
6. Start a PMC raid.
7. Confirm the server prints Client selected and LIVE SPAWN CONFIRMED.
8. Confirm the Nemesis appears by name in the live spectator bot list.
