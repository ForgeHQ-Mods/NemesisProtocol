NEMESIS PROTOCOL v1.0.1

This package uses short internal paths.

BUILD
1. Extract NP101 to a short location, for example C:\NP101
2. Run BUILD.cmd
3. Install release\NP101-install.zip into your SPT development folder

BACK UP FIRST
SPT\user\mods\ForgeHQ-NemesisProtocol\data\profiles

CHANGES IN v1.0.1
- Fixed the "rival 1" dossier so Behavior authority uses the live ORBIT detector instead of a stale value saved during the rival's previous encounter.
- The "status" command now uses the same live authority result.
- When ORBIT is detected and PreserveOrbitPmcRole is enabled, both commands display:
  Behavior authority: ORBIT / installed AI framework
- Future encounters store the same clearer ORBIT authority wording.
- No profile reset or new encounter is required.

EXPECTED STARTUP LOGS
[Nemesis Protocol] v1.0.1 bootstrap loaded.
[Nemesis Protocol] ORBIT compatibility: ACTIVE — behavior authority: ORBIT / installed AI framework.
[Nemesis Protocol] ORBIT detected at: D:\SPT Dev\BepInEx\plugins\ORBIT
[Nemesis Protocol] Nemesis Network READY. Commands: status, rivals, history, rival <name>, compatibility, help.

TEST
1. Start the correct SPT development server.
2. Open Nemesis Network in Messenger.
3. Send: compat
4. Send: rival 1
5. The dossier should show: Behavior authority: ORBIT / installed AI framework
